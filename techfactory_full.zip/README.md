# TechFactory - Quản lý sản xuất

## Chức năng chính
- CRUD sản phẩm, đơn hàng, chi tiết đơn hàng
- Truy vấn nâng cao: lọc, phân trang, prepared statement
- Tính tổng tiền đơn hàng
- Kiểm tra tồn kho khi đặt hàng

## Hướng dẫn
1. Import file sql/tech_factory.sql
2. Chạy index.php trên localhost
3. Cập nhật thông tin kết nối trong config/db.php nếu cần
