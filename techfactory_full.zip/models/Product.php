<?php
require_once __DIR__ . '/../config/db.php';

class Product {
    private $pdo;
    public function __construct($pdo) { $this->pdo = $pdo; }

    public function getAll($limit = 10, $offset = 0) {
        $stmt = $this->pdo->prepare("SELECT * FROM products ORDER BY created_at DESC LIMIT ? OFFSET ?");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->bindValue(2, $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getByPrice($minPrice) {
        $stmt = $this->pdo->prepare("SELECT * FROM products WHERE unit_price > ?");
        $stmt->execute([$minPrice]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function add($name, $price, $stock) {
        $stmt = $this->pdo->prepare("INSERT INTO products (product_name, unit_price, stock_quantity) VALUES (?, ?, ?)");
        $stmt->execute([$name, $price, $stock]);
        return $this->pdo->lastInsertId();
    }

    public function update($id, $price, $stock) {
        $stmt = $this->pdo->prepare("UPDATE products SET unit_price = ?, stock_quantity = ? WHERE id = ?");
        return $stmt->execute([$price, $stock, $id]);
    }

    public function delete($id) {
        $stmt = $this->pdo->prepare("DELETE FROM products WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function getLatest($limit = 5) {
        $stmt = $this->pdo->prepare("SELECT * FROM products ORDER BY created_at DESC LIMIT ?");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getStock($id) {
        $stmt = $this->pdo->prepare("SELECT stock_quantity FROM products WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetchColumn();
    }
}
?>