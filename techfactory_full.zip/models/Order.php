<?php
require_once __DIR__ . '/../config/db.php';

class Order {
    private $pdo;
    public function __construct($pdo) { $this->pdo = $pdo; }

    public function add($date, $customer, $note = '') {
        $stmt = $this->pdo->prepare("INSERT INTO orders (order_date, customer_name, note) VALUES (?, ?, ?)");
        $stmt->execute([$date, $customer, $note]);
        return $this->pdo->lastInsertId();
    }

    public function getAll() {
        $stmt = $this->pdo->query("SELECT * FROM orders ORDER BY id DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTotalAmount($order_id) {
        $stmt = $this->pdo->prepare("SELECT SUM(quantity * price_at_order_time) FROM order_items WHERE order_id = ?");
        $stmt->execute([$order_id]);
        return $stmt->fetchColumn();
    }
}
?>