<?php
require_once __DIR__ . '/../models/Product.php';

class OrderItem {
    private $pdo;
    public function __construct($pdo) { $this->pdo = $pdo; }

    public function add($order_id, $product_id, $quantity, $price) {
        $productModel = new Product($this->pdo);
        $stock = $productModel->getStock($product_id);
        if ($stock < $quantity) return false;

        $stmt = $this->pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price_at_order_time) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$order_id, $product_id, $quantity, $price]);
    }

    public function getByOrder($order_id) {
        $stmt = $this->pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $stmt->execute([$order_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>