<?php
require_once __DIR__ . '/../models/Product.php';
$productModel = new Product($pdo);
$products = $productModel->getAll();
?>