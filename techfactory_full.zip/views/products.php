<h2>Danh sách sản phẩm</h2>
<table border="1">
<tr><th>ID</th><th>Tên</th><th>Giá</th><th>Tồn</th><th>Ngày tạo</th></tr>
<?php foreach ($products as $p): ?>
<tr>
    <td><?= $p['id'] ?></td>
    <td><?= $p['product_name'] ?></td>
    <td><?= number_format($p['unit_price']) ?></td>
    <td><?= $p['stock_quantity'] ?></td>
    <td><?= $p['created_at'] ?></td>
</tr>
<?php endforeach; ?>
</table>