<?php
require_once 'controllers/ProductController.php';
require_once 'views/products.php';
?>